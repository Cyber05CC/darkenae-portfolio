// import React, { useState, useEffect, useRef } from 'react';
// import Navbar from './components/Navbar';
// import Hero from './components/Hero';
// import Portfolio from './components/Portfolio';
// import Plugins from './components/Plugins';
// import About from './components/About';
// import Contact from './components/Contact';
// import AIChat from './components/AIChat';
// import { Section, Theme } from './types';

// const App: React.FC = () => {
//     const [activeSection, setActiveSection] = useState<Section>(Section.HERO);
//     const [theme, setTheme] = useState<Theme>('light'); // Default to light for this design style
//     const mainRef = useRef<HTMLElement>(null);

//     const scrollToSection = (section: Section) => {
//         const element = document.getElementById(section);
//         const container = mainRef.current;

//         if (element && container) {
//             // Offset for card spacing
//             const offset = 16;

//             // Calculate position relative to the scrollable container
//             const elementTop = element.getBoundingClientRect().top;
//             const containerTop = container.getBoundingClientRect().top;
//             const currentScroll = container.scrollTop;

//             const targetPosition = currentScroll + elementTop - containerTop - offset;

//             container.scrollTo({
//                 top: targetPosition,
//                 behavior: 'smooth',
//             });
//             setActiveSection(section);
//         }
//     };

//     // Scroll spy
//     useEffect(() => {
//         const container = mainRef.current;
//         if (!container) return;

//         const handleScroll = () => {
//             const sections = Object.values(Section).filter((s) => s !== Section.CHAT);
//             for (const section of sections) {
//                 const element = document.getElementById(section);
//                 if (element) {
//                     const rect = element.getBoundingClientRect();
//                     // Check if element is in the viewport "active zone"
//                     if (rect.top <= 300 && rect.bottom >= 300) {
//                         setActiveSection(section);
//                         break;
//                     }
//                 }
//             }
//         };

//         container.addEventListener('scroll', handleScroll);
//         return () => container.removeEventListener('scroll', handleScroll);
//     }, []);

//     return (
//         <div className="bg-[#F2F4F7] h-screen text-gray-900 selection:bg-primary selection:text-white flex flex-col md:flex-row overflow-hidden">
//             {/* Sidebar Navigation */}
//             <aside className="w-full md:w-80 flex-shrink-0 z-50 p-3 md:h-full">
//                 <Navbar
//                     activeSection={activeSection}
//                     scrollToSection={scrollToSection}
//                     theme={theme}
//                     setTheme={setTheme}
//                 />
//             </aside>

//             {/* Main Content Area */}
//             <main
//                 ref={mainRef}
//                 className="flex-1 p-3 md:pl-0 space-y-3 w-full min-w-0 h-full overflow-y-auto scroll-smooth"
//             >
//                 <div className="space-y-3">
//                     <Hero scrollToSection={scrollToSection} />
//                     <Portfolio />
//                     <Plugins />
//                     <About />
//                     <Contact />
//                 </div>

//                 <footer className="py-8 text-center text-gray-400 text-sm">
//                     <p>&copy; {new Date().getFullYear()} darken Ae</p>
//                 </footer>
//             </main>

//             <AIChat />
//         </div>
//     );
// };

// export default App;
